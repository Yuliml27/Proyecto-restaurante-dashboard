// ============================================
// LÓGICA DE LA PÁGINA DE CHECKOUT
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  cargarResumenProductosCheckout();
  agregarEventosCheckout();
});

// Cargar y mostrar los productos del carrito en el checkout
function cargarResumenProductosCheckout() {
  const carrito = obtenerCarrito();
  const detalleProductos = document.querySelector('#detalle-productos-checkout');
  
  if (!detalleProductos) return;
  
  detalleProductos.innerHTML = '';
  
  carrito.forEach(producto => {
    const subtotal = producto.precio * producto.cantidad;
    const item = document.createElement('div');
    item.className = 'd-flex justify-content-between align-items-center mb-24';
    item.innerHTML = `
      <div>
        <p class="lead color-black">${producto.nombre}</p>
        <small style="color: #999;">Cantidad: ${producto.cantidad} x $${parseFloat(producto.precio).toFixed(2)}</small>
      </div>
      <p class="lead color-black">$${subtotal.toFixed(2)}</p>
    `;
    detalleProductos.appendChild(item);
  });
  
  // Actualizar total
  const subtotal = calcularSubtotal();
  const metodo = document.querySelector('input[name="metodo-pago"]:checked');
  const metodoPago = metodo ? metodo.value : 'contra-entrega';
  const total = calcularTotalCheckout(subtotal, metodoPago);
  
  const totalCheckout = document.querySelector('#total-checkout');
  if (totalCheckout) {
    totalCheckout.textContent = `$${total.toFixed(2)}`;
  }
}

// Calcular total del checkout según el método de pago
function calcularTotalCheckout(subtotal, metodoPago) {
  let impuesto = 0;
  
  if (metodoPago === 'contra-entrega') {
    impuesto = subtotal * 0.05; // 5% de impuesto
  }
  // Otros métodos no tienen impuesto adicional
  
  return subtotal + impuesto;
}

// Agregar eventos del checkout
function agregarEventosCheckout() {
  const form = document.querySelector('#form-checkout');
  
  if (!form) return;
  
  // Cambiar método de pago
  document.querySelectorAll('input[name="metodo-pago"]').forEach(radio => {
    radio.addEventListener('change', () => {
      const subtotal = calcularSubtotal();
      const metodoPago = radio.value;
      const total = calcularTotalCheckout(subtotal, metodoPago);
      
      const totalCheckout = document.querySelector('#total-checkout');
      if (totalCheckout) {
        totalCheckout.textContent = `$${total.toFixed(2)}`;
      }
    });
  });
  
  // Manejar envío del formulario
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Validar que no esté vacío el carrito
    const carrito = obtenerCarrito();
    if (carrito.length === 0) {
      alert('Tu carrito está vacío');
      return;
    }
    
    // Obtener datos del formulario
    const nombres = document.querySelector('#nombres-checkout')?.value?.trim();
    const apellidos = document.querySelector('#apellidos-checkout')?.value?.trim();
    const email = document.querySelector('#email-checkout')?.value?.trim();
    const celular = document.querySelector('#celular-checkout')?.value?.trim();
    const direccion = document.querySelector('#direccion-checkout')?.value?.trim();
    const notas = document.querySelector('#notas-checkout')?.value?.trim();
    const metodoPago = document.querySelector('input[name="metodo-pago"]:checked')?.value;
    
    // Validar campos requeridos
    if (!nombres || !apellidos || !email || !celular || !direccion) {
      alert('Por favor completa todos los campos requeridos');
      return;
    }
    
    // Validar email
    if (!validarEmail(email)) {
      alert('Por favor ingresa un email válido');
      return;
    }
    
    // Validar teléfono (al menos 10 dígitos)
    if (!validarTelefono(celular)) {
      alert('Por favor ingresa un teléfono válido (mínimo 10 dígitos)');
      return;
    }
    
    // Calcular total
    const subtotal = calcularSubtotal();
    const total = calcularTotalCheckout(subtotal, metodoPago);
    
    // Preparar datos del pedido
    const datosProductos = carrito.map(p => ({
      id_producto: p.id,
      cantidad: p.cantidad
    }));

    const pedido = {
      id_cliente: 1,
      metodo_pago: metodoPago,
      estado: 'pendiente',
      total: parseFloat(total.toFixed(2)),
      notas: notas || '',
      productos: datosProductos,
      cliente: {
        nombres,
        apellidos,
        email,
        celular,
        direccion
      }
    };
    
    // Mostrar mensaje de procesando
    const btnSubmit = form.querySelector('button[type="submit"]');
    const textoOriginal = btnSubmit.textContent;
    btnSubmit.disabled = true;
    btnSubmit.textContent = 'Procesando...';
    
    try {
      // Simular envío al servidor
      console.log('Pedido a enviar:', pedido);
      
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Generar número de pedido único
      const numeroPedido = 'PED-' + Date.now();
      
      // Guardar datos en sessionStorage para la página de agradecimiento
      sessionStorage.setItem('pedidoExitoso', JSON.stringify({
        numeroPedido: numeroPedido,
        total: pedido.total,
        cliente: nombres + ' ' + apellidos
      }));
      
      // Limpiar carrito después del pedido exitoso
      limpiarCarrito();
      
      // Redirigir a página de gracias
      window.location.href = 'thankyou.html';
      
    } catch (error) {
      console.error('Error al procesar el pedido:', error);
      alert('Hubo un error al procesar tu pedido. Por favor intenta de nuevo.');
      btnSubmit.disabled = false;
      btnSubmit.textContent = textoOriginal;
    }
  });
}

// Validar formato de email
function validarEmail(email) {
  const regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regexEmail.test(email);
}

// Validar teléfono
function validarTelefono(telefono) {
  const regexTelefono = /^\d{10,}$/;
  return regexTelefono.test(telefono.replace(/\D/g, ''));
}
