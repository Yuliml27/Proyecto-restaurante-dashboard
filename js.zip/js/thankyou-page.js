// ============================================
// LÓGICA DE LA PÁGINA DE AGRADECIMIENTO
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  mostrarConformacionPedido();
  agregarEventosBotonesThankYou();
});

// Mostrar confirmación del pedido
function mostrarConformacionPedido() {
  const datosSession = sessionStorage.getItem('pedidoExitoso');
  
  if (!datosSession) {
    // Si no hay datos del pedido, redirigir a inicio
    window.location.href = 'index.html';
    return;
  }
  
  try {
    const datos = JSON.parse(datosSession);
    
    // Actualizar número de pedido
    const numeroPedidoEl = document.querySelector('#numero-pedido-final');
    if (numeroPedidoEl) {
      numeroPedidoEl.textContent = datos.numeroPedido;
    }
    
    // Calcular tiempo estimado (random entre 30-60 minutos)
    const tiempoEstimado = Math.floor(Math.random() * (60 - 30 + 1)) + 30;
    const tiempoEntregaEl = document.querySelector('#tiempo-entrega');
    if (tiempoEntregaEl) {
      tiempoEntregaEl.textContent = tiempoEstimado + '-' + (tiempoEstimado + 15) + ' minutos';
    }
    
    // Limpiar sessionStorage después de mostrar los datos
    sessionStorage.removeItem('pedidoExitoso');
    
  } catch (error) {
    console.error('Error al procesar los datos del pedido:', error);
  }
}

// Agregar eventos a los botones
function agregarEventosBotonesThankYou() {
  const btnVolver = document.querySelector('.cus-btn');
  if (btnVolver) {
    btnVolver.addEventListener('click', (e) => {
      e.preventDefault();
      irAlInicio();
    });
  }
}
