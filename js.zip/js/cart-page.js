// ============================================
// LÓGICA DE LA PÁGINA DE CARRITO (CART.HTML)
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  cargarCarrito();
  actualizarResumenCarrito();
  agregarEventosCarrito();
});

// Cargar y mostrar los productos del carrito
function cargarCarrito() {
  const carrito = obtenerCarrito();
  const tbody = document.querySelector('#carrito-items');
  
  if (!tbody) return;
  
  // Limpiar tabla
  tbody.innerHTML = '';
  
  if (carrito.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="4" style="text-align: center; padding: 40px;">
          <p style="font-size: 16px; color: #999;">Tu carrito está vacío</p>
        </td>
      </tr>
    `;
    return;
  }
  
  // Agregar cada producto al carrito
  carrito.forEach(producto => {
    const subtotal = producto.precio * producto.cantidad;
    const fila = document.createElement('tr');
    fila.innerHTML = `
      <td class="product-block">
        <a href="#" class="remove-from-cart-btn" data-id="${producto.id}">
          <i class="fa-solid fa-x"></i>
        </a>
        <img src="${producto.imagen}" alt="${producto.nombre}">
        <a href="#" class="h6">${producto.nombre}</a>
      </td>
      <td>
        <p class="lead color-black">$${parseFloat(producto.precio).toFixed(2)}</p>
      </td>
      <td>
        <div class="quantity quantity-wrap">
          <div class="decrement" data-id="${producto.id}">
            <i class="fa-solid fa-minus"></i>
          </div>
          <input type="number" name="quantity" value="${producto.cantidad}" min="1" max="99" class="number cart-quantity" data-id="${producto.id}">
          <div class="increment" data-id="${producto.id}">
            <i class="fa-solid fa-plus"></i>
          </div>
        </div>
      </td>
      <td>
        <h6>$${subtotal.toFixed(2)}</h6>
      </td>
    `;
    tbody.appendChild(fila);
  });
}

// Agregar eventos a los botones de cantidad y eliminar
function agregarEventosCarrito() {
  const tbody = document.querySelector('#carrito-items');
  
  if (!tbody) return;
  
  // Evento para incrementar cantidad
  document.querySelectorAll('.increment').forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      const id = this.dataset.id;
      const carrito = obtenerCarrito();
      const producto = carrito.find(p => p.id == id);
      
      if (producto) {
        producto.cantidad += 1;
        guardarCarrito(carrito);
        cargarCarrito();
        actualizarResumenCarrito();
        agregarEventosCarrito(); // Re-vincular eventos
      }
    });
  });
  
  // Evento para decrementar cantidad
  document.querySelectorAll('.decrement').forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      const id = this.dataset.id;
      const carrito = obtenerCarrito();
      const producto = carrito.find(p => p.id == id);
      
      if (producto) {
        if (producto.cantidad > 1) {
          producto.cantidad -= 1;
          guardarCarrito(carrito);
          cargarCarrito();
          actualizarResumenCarrito();
          agregarEventosCarrito(); // Re-vincular eventos
        }
      }
    });
  });
  
  // Evento para eliminar producto
  document.querySelectorAll('.remove-from-cart-btn').forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      const id = this.dataset.id;
      eliminarDelCarrito(id);
      cargarCarrito();
      actualizarResumenCarrito();
      agregarEventosCarrito(); // Re-vincular eventos
    });
  });
  
  // Evento para cambiar cantidad manualmente
  document.querySelectorAll('.cart-quantity').forEach(input => {
    input.addEventListener('change', function() {
      const id = this.dataset.id;
      const nuevaCantidad = parseInt(this.value);
      
      if (nuevaCantidad > 0) {
        actualizarCantidad(id, nuevaCantidad);
        cargarCarrito();
        actualizarResumenCarrito();
        agregarEventosCarrito(); // Re-vincular eventos
      } else {
        this.value = 1;
      }
    });
  });
  
  // Evento para botón "Continuar Comprando"
  const btnContinuar = document.querySelector('.cus-btn.primary');
  if (btnContinuar) {
    btnContinuar.addEventListener('click', (e) => {
      e.preventDefault();
      irAlInicio();
    });
  }
  
  // Evento para botón "Ir a pagar"
  const btnPagar = document.querySelector('.cus-btn.dark');
  if (btnPagar) {
    btnPagar.addEventListener('click', (e) => {
      e.preventDefault();
      const carrito = obtenerCarrito();
      if (carrito.length === 0) {
        alert('Tu carrito está vacío');
      } else {
        irAlCheckout();
      }
    });
  }
}

// Actualizar el resumen del carrito (subtotal, domicilio, total)
function actualizarResumenCarrito() {
  const subtotal = calcularSubtotal();
  const domicilio = 5.00; // Costo fijo de domicilio
  const descuento = 0.00; // Sin descuento por defecto
  const total = subtotal + domicilio - descuento;
  
  // Actualizar elementos del resumen
  const subtotalEl = document.querySelector('#subtotal-resumen');
  const domicilioEl = document.querySelector('#domicilio-resumen');
  const descuentoEl = document.querySelector('#descuento-resumen');
  const totalEl = document.querySelector('#total-resumen');
  
  if (subtotalEl) subtotalEl.textContent = `$${subtotal.toFixed(2)}`;
  if (domicilioEl) domicilioEl.textContent = `$${domicilio.toFixed(2)}`;
  if (descuentoEl) descuentoEl.textContent = `-$${descuento.toFixed(2)}`;
  if (totalEl) totalEl.textContent = `$${total.toFixed(2)}`;
  
  // Guardar el total en sessionStorage para usarlo en checkout
  sessionStorage.setItem('cartTotal', total.toFixed(2));
}
