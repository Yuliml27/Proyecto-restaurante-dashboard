// ============================================
// GESTIÓN DEL CARRITO - FUNCIONES PRINCIPALES
// ============================================

// Obtener carrito desde localStorage
function obtenerCarrito() {
  const carrito = localStorage.getItem('carrito');
  return carrito ? JSON.parse(carrito) : [];
}

// Guardar carrito en localStorage
function guardarCarrito(carrito) {
  localStorage.setItem('carrito', JSON.stringify(carrito));
}

// Actualizar el contador de productos en el navbar
function actualizarContadorCarrito() {
  const carrito = obtenerCarrito();
  const contador = document.querySelector('.contar-pro');
  if (contador) {
    const total = carrito.reduce((sum, producto) => sum + producto.cantidad, 0);
    contador.textContent = total;
  }
}

// Agregar producto al carrito
function agregarAlCarrito(id, nombre, precio, imagen, cantidad = 1) {
  const carrito = obtenerCarrito();
  
  // Buscar si el producto ya existe en el carrito
  const productoExistente = carrito.find(p => p.id == id);
  
  if (productoExistente) {
    productoExistente.cantidad += cantidad;
  } else {
    carrito.push({
      id: parseInt(id),
      nombre: nombre,
      precio: parseFloat(precio),
      cantidad: cantidad,
      imagen: imagen
    });
  }
  
  guardarCarrito(carrito);
  actualizarContadorCarrito();
  mostrarNotificacion('Producto agregado al carrito');
}

// Eliminar producto del carrito
function eliminarDelCarrito(id) {
  let carrito = obtenerCarrito();
  carrito = carrito.filter(p => p.id != id);
  guardarCarrito(carrito);
  actualizarContadorCarrito();
  mostrarNotificacion('Producto eliminado del carrito');
}

// Actualizar cantidad de producto
function actualizarCantidad(id, nuevaCantidad) {
  const carrito = obtenerCarrito();
  const producto = carrito.find(p => p.id == id);
  
  if (producto) {
    if (nuevaCantidad <= 0) {
      eliminarDelCarrito(id);
    } else {
      producto.cantidad = nuevaCantidad;
      guardarCarrito(carrito);
      actualizarContadorCarrito();
    }
  }
}

// Limpiar carrito completamente
function limpiarCarrito() {
  localStorage.removeItem('carrito');
  actualizarContadorCarrito();
}

// Calcular subtotal (suma de todos los productos)
function calcularSubtotal() {
  const carrito = obtenerCarrito();
  return carrito.reduce((total, producto) => {
    return total + (producto.precio * producto.cantidad);
  }, 0);
}

// Mostrar notificación al usuario
function mostrarNotificacion(mensaje) {
  // Crear elemento de notificación
  const notificacion = document.createElement('div');
  notificacion.className = 'notificacion-carrito';
  notificacion.textContent = mensaje;
  notificacion.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background-color: #28a745;
    color: white;
    padding: 15px 20px;
    border-radius: 5px;
    z-index: 9999;
    animation: slideIn 0.3s ease-in-out;
    box-shadow: 0 2px 10px rgba(0,0,0,0.2);
  `;
  
  document.body.appendChild(notificacion);
  
  // Remover la notificación después de 2 segundos
  setTimeout(() => {
    notificacion.style.animation = 'slideOut 0.3s ease-in-out';
    setTimeout(() => notificacion.remove(), 300);
  }, 2000);
}

// Agregar estilos de animación para notificaciones
function agregarEstilosNotificacion() {
  if (!document.getElementById('estilos-notificacion')) {
    const style = document.createElement('style');
    style.id = 'estilos-notificacion';
    style.textContent = `
      @keyframes slideIn {
        from {
          transform: translateX(400px);
          opacity: 0;
        }
        to {
          transform: translateX(0);
          opacity: 1;
        }
      }
      
      @keyframes slideOut {
        from {
          transform: translateX(0);
          opacity: 1;
        }
        to {
          transform: translateX(400px);
          opacity: 0;
        }
      }
    `;
    document.head.appendChild(style);
  }
}

// Ejecutar al cargar la página
document.addEventListener('DOMContentLoaded', () => {
  agregarEstilosNotificacion();
  actualizarContadorCarrito();
});

// Navegar a carrito
function irAlCarrito() {
  window.location.href = 'cart.html';
}

// Navegar al checkout
function irAlCheckout() {
  window.location.href = 'checkout.html';
}

// Navegar al inicio
function irAlInicio() {
  window.location.href = 'index.html';
}
