// ============================================
// LÓGICA DE LA PÁGINA PRINCIPAL (INDEX.HTML)
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  // Manejar clicks en botones "agregar al carrito"
  document.querySelectorAll('.btn-product').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      
      // Encontrar la tarjeta del producto más cercana
      const card = e.target.closest('.card.producto');
      
      if (card) {
        const id = card.dataset.id;
        const nombre = card.dataset.name;
        const precio = card.dataset.price;
        const imagen = card.dataset.image;
        
        if (id && nombre && precio && imagen) {
          agregarAlCarrito(id, nombre, precio, imagen);
        }
      }
    });
  });
  
  // Manejar click en el icono del carrito para ir al carrito
  const carritoIcon = document.querySelector('.carrito');
  if (carritoIcon) {
    carritoIcon.addEventListener('click', (e) => {
      e.preventDefault();
      irAlCarrito();
    });
  }
  
  // Manejar click en el logo para mantener el comportamiento actual
  const logo = document.querySelector('#logo');
  if (logo) {
    logo.addEventListener('click', (e) => {
      if (e.target.closest('#logo') === logo) {
        // El logo ya tiene href="#", así que se mantiene el comportamiento actual
      }
    });
  }
});
